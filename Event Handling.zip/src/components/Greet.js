import React from 'react'
// function Greet() {
// 	return <h1>hello</h1>
// }

export const Greet = props => {
	const {name, heroname} = props
	// console.log(props)
	return (
		<div>
		<h1>
		Hello {name} a.k.a {heroname} 
		</h1>
		</div>
		)
}
// export default Greet