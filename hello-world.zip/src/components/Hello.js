import React from 'react'
// function Greet() {
// 	return <h1>hello</h1>
// }
const Hello = () => {
	return (
		<div>
		<h1>hello</h1>
		</div>
		)
	// return React.createElement('div', null, '<h1>hello</h1>')
}
export default Hello;