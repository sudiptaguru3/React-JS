import React from 'react'
// function Greet() {
// 	return <h1>hello</h1>
// }
const Greet = () => <h1>hello</h1>
export default Greet;