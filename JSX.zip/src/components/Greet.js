import React from 'react'
// function Greet() {
// 	return <h1>hello</h1>
// }

export const Greet = () => <h1>Hello</h1>
// export default Greet